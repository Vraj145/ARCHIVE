import { Component } from '@angular/core';

// Define the Leave interface
interface Leave {
  employee: string;
  leaveType: string;
  halfDay: string;
  startDate: string;
  endDate: string;
  reason: string;
  noOfLeaves: number;
  status: string;
}

@Component({
  selector: 'empmng-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent {
  // Declare variables and initialize them to empty values
  profilePhotoUrl = '';
  name = '';
  birthday = '';
  holidays: string[] = [];
  leaveData: Leave[] = [];

  constructor() {}

  async ngOnInit() {
    // Fetch data from the JSON file and assign it to leaveData
    try {
      const response = await fetch('./employee.json');
      const data: Leave[] = await response.json();
      this.leaveData = data;
      this.displayData(this.leaveData);
    } catch (error) {
      console.error('Error fetching data:', error);
    }

    // Set values for the other variables
    this.profilePhotoUrl = 'https://icons-for-free.com/iconfiles/png/512/login+person+profile+user+users+icon-1320166527284195604.png';
    this.name = 'John Doe';
    this.birthday = 'April 25th';
    this.holidays = ['New Year', 'Christmas', 'Thanksgiving'];
  }

  displayData(data: Leave[]) {
    const table = document.querySelector('.card-table') as HTMLTableElement;

    // Clear existing rows
    while (table.rows.length > 1) {
      table.deleteRow(1);
    }

    // Loop through data and create table rows
    data.forEach((rowData) => {
      const row = table.insertRow();

      const employeeCell = row.insertCell();
      employeeCell.textContent = rowData.employee;

      const leaveTypeCell = row.insertCell();
      leaveTypeCell.textContent = rowData.leaveType;

      const halfDayCell = row.insertCell();
      halfDayCell.textContent = rowData.halfDay;

      const startDateCell = row.insertCell();
      startDateCell.textContent = rowData.startDate;

      const endDateCell = row.insertCell();
      endDateCell.textContent = rowData.endDate;

      const reasonCell = row.insertCell();
      reasonCell.textContent = rowData.reason;

      const noOfLeavesCell = row.insertCell();
      noOfLeavesCell.textContent = rowData.noOfLeaves.toString();

      const statusCell = row.insertCell();
      statusCell.textContent = rowData.status;
    });

    // Show the table
    table.style.display = 'block';
  }
}
