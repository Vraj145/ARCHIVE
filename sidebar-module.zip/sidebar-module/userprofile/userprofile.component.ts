import { Component } from '@angular/core';

@Component({
  selector: 'empmng-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent {

}
